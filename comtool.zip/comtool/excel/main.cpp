//    main.cpp
#include <QFile>
#include <QApplication>
#include <QDebug>

#include "qexcel.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QString filename = "e:/123.xlsx"; //"D:/test.xls"具体路径
    QFile  file(filename);
    bool isExit = file.exists();
    if(!isExit)
         return false;
    qDebug()<<"isExit"<<isExit;
    qDebug()<<filename;


    //打开文件，取得工作簿
    QExcel qxls(filename);

    //取得工作表数量
    qDebug()<<"SheetCount"<<qxls.getSheetsCount();
    //激活一张工作表
    //qxls.selectSheet(1);
    //qxls.selectSheet("JSheet2");
    //取得工作表名称
    qxls.selectSheet(1);
    qxls.getSheetName();
    qDebug()<<"SheetName 1"<<qxls.getSheetName(1);
    //取得工作表已使用范围
    //int topLeftRow, topLeftColumn, bottomRightRow, bottomRightColumn;
    //qxls.getUsedRange(&topLeftRow, &topLeftColumn, &bottomRightRow, &bottomRightColumn);
    //读值
    //qxls.getCellValue(2, 2).toString();
    //删除工作表
    //qxls.selectSheet("Sheet1");
    //qxls.selectSheet(1);
    //qxls.deleteSheet();
    //qxls.save();
    //插入数据
    qxls.selectSheet(2);
    qxls.setCellString(1, 7, "addString");
    qxls.setCellString("A3", "abc");
    qxls.save();
    //合并单元格
    qxls.selectSheet(2);
    qxls.mergeCells("G1:H2");
    qxls.mergeCells(4, 7, 5 ,8);
    qxls.save();
    //设置列宽
    //qxls.selectSheet(1);
    //qxls.setColumnWidth(1, 20);
    //qxls.save();
    //设置粗体
    //qxls.selectSheet(1);
    //qxls.setCellFontBold(2, 2, true);
    //qxls.setCellFontBold("A2", true);
    //qxls.save();
    //设置文字大小
    //qxls.selectSheet(1);
    //qxls.setCellFontSize("B3", 20);
    //qxls.setCellFontSize(1, 2, 20);
    //qxls.save();
    //设置单元格文字居中
    //qxls.selectSheet(2);
    //qxls.setCellTextCenter(1, 2);
    //qxls.setCellTextCenter("A2");
    //qxls.save();
    //设置单元格文字自动折行
    //qxls.selectSheet(1);
    //qxls.setCellTextWrap(2,2,true);
    //qxls.setCellTextWrap("A2", true);
    //qxls.save();
    //设置一行自适应行高
    //qxls.selectSheet(1);
    //qxls.setAutoFitRow(2);
    //qxls.save();
    //新建工作表
    //qxls.insertSheet("abc");
    //qxls.save();
    //清除单元格内容
    //qxls.selectSheet(4);
    //qxls.clearCell(1,1);
    //qxls.clearCell("A2");
    //qxls.save();
    //合并一列中相同连续的单元格
    //qxls.selectSheet(1);
    //qxls.mergeSerialSameCellsInColumn(1, 2);
    //qxls.save();
    //获取一张工作表已用行数
    //qxls.selectSheet(1);
    //qDebug()<<qxls.getUsedRowsCount();
    //设置行高
        //qxls.selectSheet(1);
        //qxls.setRowHeight(2, 30);
        //qxls.save();

    qxls.close();

    qDebug()<<"App End";
    return a.exec();
}
